﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using LinqGrouping.Models;

namespace LinqGrouping.Controllers
{
    public class GroupingController : Controller
    {
        public ActionResult Index()
        {
            var books = new List<Book>();

            // Add test data
            books.Add(new Book { Author = "Douglas Adams", Title = "The Hitchhiker's Guide to the Galaxy", Genre = "Fiction", Price = 159.95M });
            books.Add(new Book { Author = "Scott Adams", Title = "The Dilbert Principle", Genre = "Fiction", Price = 23.95M });
            books.Add(new Book { Author = "Douglas Coupland", Title = "Generation X", Genre = "Fiction", Price = 300.00M });
            books.Add(new Book { Author = "Walter Isaacson", Title = "Steve Jobs", Genre = "Biography", Price = 219.25M });
            books.Add(new Book { Author = "Michael Freeman", Title = "The Photographer's Eye", Genre = "Photography", Price = 195.50M });

            // Group the books by Genre
            var booksGrouped = from b in books
                               group b by b.Genre into g
                               select new Group<string, Book> { Key = g.Key, Values = g };

            return View(booksGrouped.ToList());
        }

    }
}
