﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LinqGrouping.Models
{
    public class Group<K, T>
    {
        public K Key;
        public IEnumerable<T> Values;
    }

    public class Book
    {
        public string Title;
        public string Author;
        public string Genre;
        public decimal Price;
    }
}