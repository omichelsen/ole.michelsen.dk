﻿using System.Web.Mvc;
using QueryStringAlias.Models;

namespace QueryStringAlias.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(ExampleAliasModel model)
        {
            return View(model);
        }
    }
}
