﻿using System.Web.Mvc;
using QueryStringAlias.Attributes;
using QueryStringAlias.ModelBinders;

namespace QueryStringAlias.Models
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class ExampleAliasModel
    {
        [BindAlias("c")]
        public int CategoryId { get; set; }

        [BindAlias("s")]
        [BindAlias("sort")]
        public string SortBy { get; set; }

        [BindAlias("asc")]
        public bool SortAscending { get; set; }
    }
}