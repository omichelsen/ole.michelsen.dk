﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SerializeToQueryString.Tests
{
    public class MixedAccessorClassTest
    {
        public MixedAccessorClassTest(string publicProperty, string privateProperty, string publicVariable)
        {
            PublicProperty = publicProperty;
            PrivateProperty = privateProperty;
            PublicVariable = publicVariable;
        }

        public string PublicProperty { get; set; }
        private string PrivateProperty { get; set; }
        public string PublicVariable;
    }
}
