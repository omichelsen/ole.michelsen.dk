﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using SerializeToQueryString.Helpers;
using SerializeToQueryString.Models;

namespace SerializeToQueryString.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var request = new WebServiceRequest()
                              {
                                  text = "Hello World!",
                                  number = 42.69,
                                  integer = 50,
                                  truthiness = false,
                                  dontinclude = "notincluded",
                                  array = new[] {"bar", "disco"},
                                  collection = new List<int>() {1, 2, 3, 5, 8, 13, 21, 34}
                              };

            var model = new HomeIndexViewModel();

            model.Request = request;

            model.RequestAsQueryString = request.ToQueryString();

            var serializer = new JavaScriptSerializer();
            model.RequestAsJson = serializer.Serialize(request);

            return View(model);
        }
    }
}
