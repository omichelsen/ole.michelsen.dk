﻿using System.Collections.Generic;

namespace SerializeToQueryString.Models
{
    public class WebServiceRequest
    {
        public string text { get; set; }
        public double number { get; set; }
        public int integer { get; set; }
        public bool truthiness { get; set; }
        public string dontinclude;
        public string[] array { get; set; }
        public List<int> collection { get; set; }
    }
}