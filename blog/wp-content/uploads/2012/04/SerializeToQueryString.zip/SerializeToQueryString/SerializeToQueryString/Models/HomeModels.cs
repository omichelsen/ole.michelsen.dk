﻿namespace SerializeToQueryString.Models
{
    public class HomeIndexViewModel
    {
        public WebServiceRequest Request { get; set; }
        public string RequestAsJson { get; set; }
        public string RequestAsQueryString { get; set; }
    }
}