﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LinqResourceFallback.Models
{
    public class ArticleViewModel
    {
        public Article Article { get; set; }
        public ArticleTranslation Translation { get; set; }
    }
}