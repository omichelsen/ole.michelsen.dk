﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using LinqResourceFallback.Models;

namespace LinqResourceFallback.Controllers
{
    public class ArticleController : Controller
    {
        private List<Article> Articles = new List<Article>();
        private List<ArticleTranslation> Translations = new List<ArticleTranslation>();

        //
        // Create test data on load

        public ArticleController()
        {
            // Add article #1 with English and Danish translation
            Articles.Add(new Article() { ArticleId = 1, Permalink = "Article1", PubDate = DateTime.Now.AddMinutes(10) });
            Translations.Add(new ArticleTranslation() { ArticleId = 1, LanguageId = "en", Title = "Article #1", Body = "English fallback translation." });
            Translations.Add(new ArticleTranslation() { ArticleId = 1, LanguageId = "da", Title = "Article #1", Body = "Dansk oversættelse fundet." });

            // Add article #2 with English only
            Articles.Add(new Article() { ArticleId = 2, Permalink = "Article2", PubDate = DateTime.Now.AddMinutes(20) });
            Translations.Add(new ArticleTranslation() { ArticleId = 2, LanguageId = "en", Title = "Article #2", Body = "English fallback translation." });
        }


        //
        // GET: /Article/

        public ActionResult Index()
        {
            string languageSelected = "da",
                   languageFallback = "en";

            var model = from a in Articles
                        join t in Translations on 
                            new { a.ArticleId, LanguageId = languageSelected } equals 
                            new { t.ArticleId, t.LanguageId } 
                            into LanguageSelected
                        join t in Translations on 
                            new { a.ArticleId, LanguageId = languageFallback } equals 
                            new { t.ArticleId, t.LanguageId } 
                            into LanguageFallback
                        from selected in LanguageSelected.DefaultIfEmpty()
                        from fallback in LanguageFallback.DefaultIfEmpty()
                        orderby a.PubDate
                        select new ArticleViewModel()
                        {
                            Article = a,
                            Translation = selected ?? fallback,
                        };

            return View(model.ToList());
        }
        
    }
}
